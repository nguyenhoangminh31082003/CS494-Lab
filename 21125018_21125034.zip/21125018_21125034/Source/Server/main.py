import sys

from ServerModel import ServerModel

if __name__ == "__main__":
    server = ServerModel()
    server.run()