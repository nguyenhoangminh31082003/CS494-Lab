import enum

class GameStatusID(enum.IntEnum):
    PLAYER = 0
    WATCHER = 1