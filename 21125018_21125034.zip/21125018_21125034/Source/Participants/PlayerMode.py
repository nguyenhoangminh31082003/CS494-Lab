import enum

class PlayerMode(enum.IntEnum):
    PLAY = 0
    WATCH = 1
    DIE = 2
    WAIT = 3